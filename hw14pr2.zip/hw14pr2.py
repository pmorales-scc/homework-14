
#
# hw14pr2.py
#

from csci1550png import *
import copy


def change( p ):
    """ change takes in a pixel (an [R,G,B] list)
        and returns a new pixel to take its place!
    """
    red = p[0]
    green = p[1]
    blue = p[2]
    return [ 255-red, 255-green, 255-blue ]


def invert(fname = 'in.png'):
    """Run this function to read the in.png image,
       change it, and write the result to out.png.
    """
    Im_pix = getRGB(fname)  # read in the in.png image
    print("The first two pixels of the first row are", Im_pix[0][0:2])
    #
    # Remember that Im_pix is a list (the image)
    # of lists (each row) of lists (each pixel is [R,G,B])
    #
    New_pix = copy.deepcopy(Im_pix)
    [numCols, numRows] = getWH(New_pix)
    for rowInd in range(numRows):
        for colInd in range(numCols):
            New_pix[rowInd][colInd] = change(New_pix[rowInd][colInd])
    # now, save to the file 'out.png'
    saveRGB(New_pix, 'out.png')
    
# test it out!
invert('spam.png')



def testBinaryImage():
    """ run this function to create an 8x8 alien image
        named binary.png
    """
    ALIEN = "0"*8 + "11011011"*2 + "0"*8 + "00001000" + \
            "01000010" + "01111110" + "0"*8
    # this function is imported from cs1550png.py
    NUM_ROWS = 8
    NUM_COLS = 8
    binaryIm( ALIEN, NUM_COLS, NUM_ROWS )
    # that should create a file, binary.png, in this
    # directory with the 8x8 image...


    


